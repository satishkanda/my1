package com.jpa.lab2;

import java.util.Scanner;

public class Lab2_Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		Implementation impl = new Implementation();
		System.out.println("enter 1 to continue or 0 to exit");
		int ch = sc.nextInt();
		while (ch != 0) {
			System.out.println("1. Insert");
			System.out.println("2. booklist");
			System.out.println("3. getBooksByAuthor");
			System.out.println("4. getBookByPrice");
			System.out.println("5. getByIsbn");
			System.out.println("enter choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				impl.Insert();
				break;
			case 2:
				impl.booklist();
				break;
				case 3:
				impl.getBooksByAuthor();
				break;
					case 4:
				impl.getBookByPrice();
				break;
				case 5:
				impl.getByIsbn();
				break;
				default:
				System.out.println("Invalid Selection");
			}

		}
	}

}
