package com.jpa.lab2;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Implementation {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	Scanner sc = new Scanner(System.in);

	void Insert() {
		Author1 a1 = new Author1();
		System.out.println("enter Author Name");
		a1.setName(sc.nextLine());
		Book b1 = new Book();
		System.out.println("enter book Name");
		b1.setTitle(sc.nextLine());
		System.out.println("enter Price");
		b1.setPrice(sc.nextInt());
		sc.nextLine();
		Book b2 = new Book();
		System.out.println("enter Book Name");
		b2.setTitle(sc.nextLine());
		System.out.println("enter Price");
		b2.setPrice(sc.nextInt());
		b2.setAuthor1(a1);
		b1.setAuthor1(a1);

		a1.getBooks().add(b1);
		a1.getBooks().add(b2);
		em.getTransaction().begin();
		em.persist(a1);
		em.getTransaction().commit();
	}

	public void booklist() {
		TypedQuery<Book> query = em.createQuery("from Book", Book.class);
		List<Book> list = query.getResultList();
		for (Book b1 : list)
			System.out.println(b1);

	}

	public void getBooksByAuthor() {

		System.out.println("enter Author Name");
		String aName = sc.next();
		TypedQuery<Author1> query1 = em.createQuery(" from Author1 where name=? ", Author1.class);
		query1.setParameter(1, aName);
		Author1 singleResult = query1.getSingleResult();
		System.out.println(singleResult.getBooks());

	}

	public void getBookByPrice() {

		System.out.println("enter price Range");
		float min = sc.nextInt();
		float max = sc.nextInt();
		TypedQuery<Book> query2 = em.createQuery("from Book where price>=? and price<=?", Book.class);
		query2.setParameter(1, min);
		query2.setParameter(2, max);
		List<Book> list2 = query2.getResultList();
		for (Book b : list2)
			System.out.println(b);

	}

	public void getByIsbn() {
		System.out.println("enter Isbn");
		int isbn1 = sc.nextInt();
		TypedQuery<Book> query3 = em.createQuery("from Book where isbn=?", Book.class);
		query3.setParameter(1, isbn1);
		System.out.println(query3.getSingleResult().getAuthor1().getName());
	}
}
