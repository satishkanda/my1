package com.jpa;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AuthorImpl {
	Scanner sc=new Scanner(System.in);
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();

	void Insert() {
		Author author = new Author();
//		System.out.println("enter authorId");
//		author.setAuthorId(sc.nextInt());
		System.out.println("enter firstName");
		author.setFirstName(sc.next());
		System.out.println("enter MiddleName");
		author.setMiddleName(sc.next());
		System.out.println("enter Last Name");
		author.setLastName(sc.next());
		System.out.println("Enter phone Number");
		author.setPhoneNo(Long.parseLong(sc.next()));

		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
		System.out.println(author);
	}

	void update() {
		System.out.println("enter AuthorId you want to update");
		Author a1 = em.find(Author.class, sc.nextInt());
		System.out.println("what you want to update");
		int ch =Integer.parseInt(sc.next());
		switch (ch) {
		case 1:
			System.out.println("enter first name to update");
			a1.setFirstName(sc.next());
			break;
		case 2:
			System.out.println("enter middle name to update");
			a1.setMiddleName(sc.next());
			break;
		case 3:
			System.out.println("enter last name to update");
			a1.setLastName(sc.next());
			break;

		case 4:
			System.out.println("enter phone no to update");
			a1.setPhoneNo(sc.nextLong());
			break;
		default:
			System.out.println("Invalid choice");
		}
		em.getTransaction().begin();
		em.persist(a1);
		em.getTransaction().commit();
		System.out.println(a1);
	}

	void delete() {
		System.out.println("id to delete");
		Author a2 = em.find(Author.class, Integer.parseInt(sc.next()));
		em.getTransaction().begin();
		em.remove(a2);
		em.getTransaction().commit();
		System.out.println("Deleted");
	}

}
