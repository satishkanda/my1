package com.jpa;

import java.util.Scanner;

public class Author_Main {
		public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		AuthorImpl impl = new AuthorImpl();
		int choice;

		do {
			System.out.println("1 .Insert");
			System.out.println("2.Update");
			System.out.println("3. Delete");
			System.out.println("4. Show");
			System.out.println("4. Exit");
			System.out.println("enter choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				impl.Insert();
				break;

			case 2:
				impl.update();
				break;

			case 3:
				impl.delete();
				break;
			default:
				System.out.println("Invalid");
			}
		} while (choice != 4);
		sc.close();

	}

}
