package com.parallel.spring.exceptions;

public class AccountMismatchException extends Exception{
	public  AccountMismatchException(String message)
	{
		super(message);
	}

}
