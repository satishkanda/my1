package com.jpa.dao;

import java.sql.Date;

import javax.security.auth.login.AccountNotFoundException;

import com.jpa.beans.Account;
import com.jpa.exceptions.InsufficientBalanceException;

public interface DaoInterface {
	void createAccount(Account account);

	void deposit(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;

	void withdraw(int accno, double balance) throws InsufficientBalanceException, AccountNotFoundException;
	
	void query();
	
	void fundstransfer(int accno11, int accno12, double currbalance1, double currentbalance2) throws InsufficientBalanceException,AccountNotFoundException;

	String calcQuery(String query) throws AccountNotFoundException;

}
