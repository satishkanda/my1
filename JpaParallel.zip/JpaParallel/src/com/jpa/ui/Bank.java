package com.jpa.ui;

import java.util.Scanner;

import javax.security.auth.login.AccountNotFoundException;

import com.jpa.beans.Account;
import com.jpa.beans.Customer;
import com.jpa.exceptions.InsufficientBalanceException;
import com.jpa.service.BankingServiceImpl;

public class Bank {
	static Scanner sc = new Scanner(System.in);

	private static String input(String string) {
		String message = string;
		System.out.println(message);
		return sc.next();
	}

	private static Account createCustomer() {
		Account account = new Account();
		Customer customer = new Customer();
		account.setAccType(input("Enter Account Type"));
		customer.setName(input("enter Name"));
		customer.setMobile(input("enter Mobile no"));
		customer.setCity(input("enter city"));
		customer.setDno(input("enter door no"));
		customer.setPincode(input("enter pincode"));

		account.setCustomer(customer);
		return account;
	}

	public static void main(String[] args) {
		BankingServiceImpl impl = new BankingServiceImpl();
		String choice = null;
		do {
			System.out.println("welcome to Abc Bank");
			System.out.println("1 :Create Account");
			System.out.println("2 :Deposit");
			// System.out.println("3 :Show Balance");
			System.out.println("3 :with draw");
			System.out.println("4 :Funds Transfer");
			// System.out.println("6 :Print Transactions");
			System.out.println("5: Delete");
			System.out.println("6 : Query");
			System.out.println("Enter Choice: ");
			choice = sc.next();
			// sc.nextLine();

			switch (choice) {
			case "1":
				impl.createAccount(createCustomer());
				System.out.println("Account created Successfully");
				break;
			case "2":
				try {
					impl.deposit();
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
					e.printStackTrace();
				}
				break;

			case "3":
				try {
					impl.withdraw();
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
					e.printStackTrace();
				}
				break;
			case "4":
				try {
					impl.fundsTransfer();
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case "6":
				impl.query();
				break;

			}
		} while (choice.length() != 0);

	}

}
