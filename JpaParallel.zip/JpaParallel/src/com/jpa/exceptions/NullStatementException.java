package com.jpa.exceptions;

public class NullStatementException {

}
