package com.jpa.exceptions;

import java.util.Scanner;

public class AccountNotFoundException extends Exception{

	public AccountNotFoundException(int accno, String string) {
		super(accno+" "+string);
		Scanner sc=new Scanner(System.in);
		System.err.println(accno+" "+string);
		sc.nextLine();
		
	}

}
