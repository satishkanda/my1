package com.jpa.service;

import java.util.Scanner;

import javax.security.auth.login.AccountNotFoundException;

import com.jpa.beans.Account;
import com.jpa.dao.DaoImpl;
import com.jpa.exceptions.InsufficientBalanceException;

public class BankingServiceImpl implements BankingService {

	static Scanner sc = new Scanner(System.in);
	DaoImpl daoImpl = new DaoImpl();

	@Override
	public void createAccount(Account account) {
		daoImpl.createAccount(account);
	}

	@Override
	public void deposit() throws InsufficientBalanceException, AccountNotFoundException {
		System.out.println("enter Account no to withdraw");
		int accountno = sc.nextInt();
		System.out.println("Enter Amount to Withdraw");
		double amount = sc.nextDouble();
		String query="select accno from Account where accno="+accountno;
		int accno=Integer.parseInt(daoImpl.calcQuery(query));
		if(accno==accountno)
		{
		daoImpl.deposit(accountno, amount);
		System.out.println("Deposited Successfully");
		}
		else
		{
			throw new AccountNotFoundException("Account not Found");
			
		}

	}

	public java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Override
	public void withdraw() throws InsufficientBalanceException, AccountNotFoundException {
		System.out.println("enter Account no to withdraw");
		int accountno = sc.nextInt();
		System.out.println("Enter Amount to Withdraw");
		double amount = sc.nextDouble();
		String query="select accno from Account where accno="+accountno;
		int accno=Integer.parseInt(daoImpl.calcQuery(query));
		if(accno==accountno)
		{
			daoImpl.withdraw(accountno, amount);

		System.out.println("Deposited Successfully");
		}
		else
		{
			throw new AccountNotFoundException("Account not Found");
		}
		
	}

	public void fundsTransfer() throws InsufficientBalanceException,AccountNotFoundException{
		
		
	}

	public void query() {
		daoImpl.query();
		
	}

}
