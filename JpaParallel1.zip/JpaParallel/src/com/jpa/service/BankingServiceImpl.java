package com.jpa.service;

import java.util.Scanner;

import javax.security.auth.login.AccountNotFoundException;

import com.jpa.beans.Account;
import com.jpa.dao.DaoImpl;
import com.jpa.exceptions.InsufficientBalanceException;

public class BankingServiceImpl implements BankingService {

	static Scanner sc = new Scanner(System.in);
	DaoImpl daoImpl = new DaoImpl();

	@Override
	public void createAccount(Account account) {
		daoImpl.createAccount(account);
	}

	@Override
	public void deposit() throws InsufficientBalanceException, AccountNotFoundException {
		System.out.println("enter Account no to deposit");
		int accountno = sc.nextInt();
		System.out.println("Enter Amount to deposit");
		double amount = sc.nextDouble();
		String query="select accno from Account where accno="+accountno;
		int accno=Integer.parseInt(daoImpl.calcQuery(query));
		if(accno==accountno)
		{
		daoImpl.deposit(accountno, amount);
		System.out.println("Deposited Successfully");
		}
		else
		{
			throw new AccountNotFoundException("Account not Found");
			
		}

	}

	public java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Override
	public void withdraw() throws InsufficientBalanceException, AccountNotFoundException {
		System.out.println("enter Account no to withdraw");
		int accountno = sc.nextInt();
		System.out.println("Enter Amount to Withdraw");
		double amount = sc.nextDouble();
		String query="select accno from Account where accno="+accountno;
		int accno=Integer.parseInt(daoImpl.calcQuery(query));
		if(accno==accountno)
		{
			daoImpl.withdraw(accountno, amount);

		System.out.println("Deposited Successfully");
		}
		else
		{
			throw new AccountNotFoundException("Account not Found");
		}
		
	}

	public void fundsTransfer() throws InsufficientBalanceException,AccountNotFoundException{
		System.out.println("enter Sender Account no");
		int accno1=sc.nextInt();
		System.out.println("Enter Receiver's  account no");
		int accno2=sc.nextInt();
		String query="select accno from Account where accno="+accno1;
		int accno11=Integer.parseInt(daoImpl.calcQuery(query));
		String query1="select accno from Account where accno="+accno2;
		int accno12=Integer.parseInt(daoImpl.calcQuery(query));
		if(accno1!=accno11)
		{
			throw new AccountNotFoundException("Enter Valid Sender Account no");
		}
		else if(accno2!=accno12)
		{
			throw new AccountNotFoundException("Enter Valid Receiver's Account no");
		}
		else
		{
			System.out.println("Enter amount to be Transfered");
			double amount=sc.nextDouble();
			String query3="select accno from Account where accno="+accno1;
			double initbal1=Double.parseDouble(daoImpl.calcQuery(query3));
			String query4="select accno from Account where accno="+accno2;
			double initbal2=Double.parseDouble(daoImpl.calcQuery(query4));
			if(initbal1<amount)
			{
				throw new InsufficientBalanceException(accno1, "transfer amount lessthan initial balance");
			}
			else
			{
				double currbalance1=initbal1-amount;
				double currentbalance2=initbal2+amount;
			}
		}
	
		
	}

	public void query() {
		daoImpl.query();
		
	}

}
