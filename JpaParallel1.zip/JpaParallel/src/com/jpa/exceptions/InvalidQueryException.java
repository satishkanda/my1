package com.jpa.exceptions;

public class InvalidQueryException {

}
